package com.atguigu.service;

import com.atguigu.pojo.Cart;
import com.atguigu.pojo.Order;
import com.atguigu.pojo.OrderItem;
import com.atguigu.pojo.User;

import java.util.List;

public interface OrderService {
    public String createOrder(Cart cart,Integer userId);
    public List<OrderItem> queryItemByUser(User user);
    public List<Order> queryOrderByUser(User user);
    public List<OrderItem> queryItemByOrder(String order);
    public List<Order> queryAllOrder();
    public int setStatusById(String ID,int status);
}
