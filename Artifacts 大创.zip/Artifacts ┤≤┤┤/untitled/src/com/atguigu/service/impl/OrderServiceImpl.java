package com.atguigu.service.impl;

import com.atguigu.dao.BookDao;
import com.atguigu.dao.OrderDao;
import com.atguigu.dao.OrderItemDao;
import com.atguigu.dao.impl.BookDaoImpl;
import com.atguigu.dao.impl.OrderDaoImpl;
import com.atguigu.dao.impl.OrderItemDaoImpl;
import com.atguigu.pojo.*;
import com.atguigu.service.OrderService;

import java.util.Date;
import java.util.List;
import java.util.Map;

public class OrderServiceImpl implements OrderService {
    public OrderServiceImpl() {
    }

    private OrderDao orderDao = new OrderDaoImpl();
    private OrderItemDao orderItemDao = new OrderItemDaoImpl();
    private BookDao bookDao = new BookDaoImpl();
    @Override
    public String createOrder(Cart cart, Integer userId) {
        String orderId = ""+System.currentTimeMillis()+userId;
        Order order = new Order(orderId,new Date(),cart.getTotalPrice(),0,userId);
        int i = orderDao.saveOrder(order);
        Map<Integer, CartItem> items = cart.getItems();

        for(Map.Entry<Integer, CartItem> entry : items.entrySet()){
            CartItem cartItem = entry.getValue();
            OrderItem orderItem =
                    new OrderItem(null,cartItem.getName(),cartItem.getCount(),cartItem.getPrice(),cartItem.getTotalPrice(),orderId);
            orderItemDao.saveOrderItem(orderItem);
            Goods goods = bookDao.queryById(cartItem.getId());
            goods.setSales(goods.getSales()+cartItem.getCount());
            goods.setStock(goods.getStock()-cartItem.getCount());
            bookDao.updateBook(goods);

        }
        cart.clear();
        return orderId;
    }

    @Override
    public List<OrderItem> queryItemByUser(User user) {
        return orderDao.queryItemByUser(user);
    }

    @Override
    public List<Order> queryOrderByUser(User user) {

        return orderDao.queryOrderByUser(user);

    }

    @Override
    public List<OrderItem> queryItemByOrder(String order) {

        return orderDao.queryItemByOrder(order);
    }

    @Override
    public List<Order> queryAllOrder() {
        return orderDao.queryAllOrder();
    }

    @Override
    public int setStatusById(String ID, int status) {
        return orderDao.setStatusById(ID,status);
    }


}
