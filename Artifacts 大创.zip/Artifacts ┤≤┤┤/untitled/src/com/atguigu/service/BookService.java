package com.atguigu.service;

import com.atguigu.pojo.Goods;
import com.atguigu.pojo.Page;

import java.util.List;

public interface BookService {
    public void addBook(Goods goods);
    public void deleteBookById(Integer id);
    public void updateBook(Goods goods);
    public Goods queryById(Integer id);
    public List<Goods> queryBooks();
    public Page<Goods> page(int pageNo, int pageSize);

    Page pageByprice(int pageNo, int pageSize, int min, int max);
}
