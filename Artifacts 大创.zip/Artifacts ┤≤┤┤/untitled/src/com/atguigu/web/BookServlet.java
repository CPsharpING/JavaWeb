package com.atguigu.web;

import com.atguigu.pojo.Goods;
import com.atguigu.pojo.Page;
import com.atguigu.service.BookService;
import com.atguigu.service.impl.BookServiceImpl;
import com.atguigu.utils.WebUtils;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

public class BookServlet extends BaseServlet{
    BookService bookService = new BookServiceImpl();
    protected void add(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Goods goods = WebUtils.copyParamToBean(req.getParameterMap(),new Goods());
        bookService.addBook(goods);
        //req.getRequestDispatcher("/manager/bookServlet").forward(req,resp); 请求转发有bug 按f5的话
        int pageNo = WebUtils.parseInt(req.getParameter("pageNo"), 1)+1;
        resp.sendRedirect(req.getContextPath()+"/manager/bookServlet?action=page&pageNo="+pageNo); //重定向到端口号 请求转发到工程名
    }
    protected void delete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String id = req.getParameter("id");
        bookService.deleteBookById( WebUtils.parseInt(id,0));

        System.out.println(req.getParameter("pageNo"));
        resp.sendRedirect(req.getContextPath()+"/manager/bookServlet?action=page&pageNo="+req.getParameter("pageNo")); //重定向到端口号 请求转发到工程名
    }
    protected void update(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Goods goods = WebUtils.copyParamToBean(req.getParameterMap(),new Goods());
//        String id = req.getParameter("id");
//        System.out.println(id);
//        book.setId(WebUtils.parseInt(id,0));
        System.out.println(goods);
        bookService.updateBook(goods);
        resp.sendRedirect(req.getContextPath()+"/manager/bookServlet?action=page&pageNo="+req.getParameter("pageNo")); //重定向到端口号 请求转发到工程名
    }

    protected void list(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //1 通过BookService查询全部图书
        List<Goods> goods = bookService.queryBooks();
        //books.forEach(System.out::println);
        //2 把全部图书保存到Request域中
        req.setAttribute("books", goods);
        //3、请求转发到/pages/manager/book_manager.jsp页面
        req.getRequestDispatcher("/pages/manager/book_manager.jsp").forward(req,resp);

    }

    protected void getBook(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int id = WebUtils.parseInt(req.getParameter("id"),0);
        Goods goods = bookService.queryById(id);
        System.out.println(goods);
        req.setAttribute("book", goods);
        req.getRequestDispatcher("/pages/manager/book_edit.jsp").forward(req,resp);


    }
    protected void page(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int pageNo = WebUtils.parseInt(req.getParameter("pageNo"), 1);
        int pageSize = WebUtils.parseInt(req.getParameter("pageSize"), Page.PAGE_SIZE);
        Page page = bookService.page(pageNo, pageSize);
        page.setUrl("manager/bookServlet?action=page");
        req.setAttribute("page",page);
        req.getRequestDispatcher("/pages/manager/book_manager.jsp").forward(req,resp);

    }



}





