package com.atguigu.web;

import com.atguigu.pojo.Cart;
import com.atguigu.pojo.Order;
import com.atguigu.pojo.OrderItem;
import com.atguigu.pojo.User;
import com.atguigu.service.OrderService;
import com.atguigu.service.impl.OrderServiceImpl;
import com.atguigu.utils.JdbcUtils;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

public class OrderServlet extends BaseServlet{
    private OrderService orderService = new OrderServiceImpl();
    protected void createOrder(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();

        Cart cart = (Cart) session.getAttribute("cart");
        User user = (User) session.getAttribute("user");

        if(user==null){
            req.getRequestDispatcher("/pages/user/login.jsp").forward(req,resp);
            return;
        }
        if(cart!=null){
            String order = null;

            order = orderService.createOrder(cart, user.getId());


            session.setAttribute("orderId",order);
            resp.sendRedirect(req.getContextPath()+"/pages/cart/checkout.jsp");
        }



    }

    protected void listItem(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        User user = (User)session.getAttribute("user");
        List<OrderItem> orderItems = orderService.queryItemByUser(user);
        req.setAttribute("orderItems", orderItems);
        req.getRequestDispatcher("/pages/order/order.jsp").forward(req,resp);
    }
    protected void listOrder(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        User user = (User)session.getAttribute("user");
        System.out.println(user);
        List<Order> orders = orderService.queryOrderByUser(user);
        System.out.println(orders);

        req.setAttribute("orders", orders);
        req.getRequestDispatcher("/pages/order/order.jsp").forward(req,resp);
    }

    protected void listItemByOrder(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String orderId = req.getParameter("orderId");
        List<OrderItem> orderItems = orderService.queryItemByOrder(orderId);
        req.setAttribute("orderItems",orderItems);
        String Tips = "";
        for (OrderItem o:orderItems){
            Tips += o.getName() + ' ';

        }
        System.out.println(Tips);
        resp.getWriter().print("<script> alert(\""+ Tips +"\");"+"window.location='"+req.getHeader("Referer")+"'"+" </script>");

    }

    protected void listAllOrder(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        List<Order> orders = orderService.queryAllOrder();
        req.setAttribute("orders",orders);
        req.getRequestDispatcher("/pages/manager/order_manager.jsp").forward(req,resp);
    }


    protected void setStatus(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String orderId = req.getParameter("orderId");
        int i = orderService.setStatusById(orderId, 1);
        resp.sendRedirect(req.getHeader("Referer"));

    }
}
