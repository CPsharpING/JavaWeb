package com.atguigu.dao;

import com.atguigu.dao.impl.BaseDao;
import com.atguigu.pojo.User;

public interface UserDao  {

    public User queryUserByUsername(String username);//通过姓名查询
    public int saveUser(User user);//保存用户信息
    public User queryUserByUsernameAndPassword(String username,String password);//登录验证用户

}
