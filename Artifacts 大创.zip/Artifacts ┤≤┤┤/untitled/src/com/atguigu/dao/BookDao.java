package com.atguigu.dao;

import com.atguigu.pojo.Goods;

import java.util.List;

public interface BookDao {
    public int addBook(Goods goods);
    public int deleteBookById(Integer id);
    public int updateBook(Goods goods);
    public Goods queryById(Integer id);
    public List<Goods> queryBooks();

    Integer queryForPageTotalCount();

    List<Goods> queryForPageItems(int begin, int pageSize);

    List<Goods> queryForPageItemsByprice(int begin, int pageSize, int min, int max);

    Integer queryForPageTotalCountByprice(int min, int max);
}
