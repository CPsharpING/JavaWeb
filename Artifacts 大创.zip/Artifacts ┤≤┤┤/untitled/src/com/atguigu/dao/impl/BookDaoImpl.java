package com.atguigu.dao.impl;

import com.atguigu.dao.BookDao;
import com.atguigu.pojo.Goods;

import java.util.List;

public class BookDaoImpl extends BaseDao implements BookDao {

    @Override
    public int addBook(Goods goods) {
        String sql = "insert into t_book( `name` , `author` , `price` , `sales` , `stock` , `img_path`) " +
                "values( ?, ? , ? , ? , ? , ?)";
        update(sql, goods.getName(), goods.getAuthor(), goods.getPrice(), goods.getSales(), goods.getStock(), goods.getImgPath());
        return 0;
    }

    @Override
    public int deleteBookById(Integer id) {
        String sql = "delete from t_book where id = ?";

        return update(sql,id);
    }

    @Override
    public int updateBook(Goods goods) {
        String sql = "update t_book set `name`=? , `author`=? , `price`=? , `sales`=? , `stock`=? , `img_path`=? where id = ?";
        return update(sql, goods.getName(), goods.getAuthor(), goods.getPrice(), goods.getSales(), goods.getStock(), goods.getImgPath(), goods.getId());
    }

    @Override
    public Goods queryById(Integer id) {
        String sql = "select `id`,`name` , `author` , `price` , `sales` , `stock` , `img_path` imgPath From t_book where id = ?";
        Goods goods = queryForOne(Goods.class, sql, id);
        return goods;
    }

    @Override
    public List<Goods> queryBooks() {
        String sql = "select `id`,`name` , `author` , `price` , `sales` , `stock` , `img_path` imgPath From t_book ";
        return queryForList(Goods.class,sql);
    }

    @Override
    public Integer queryForPageTotalCount() {
        String sql = "select COUNT(*) from t_book";
        Number count = (Number)queryForSingleValue(sql);
        return count.intValue();
    }

    @Override
    public List<Goods> queryForPageItems(int begin, int pageSize) {
        String sql = "select `id`,`name` , `author` , `price` , `sales` , `stock` , `img_path` imgPath From t_book WHERE `stock`>1 LIMIT ?,?";
        List<Goods> goods = queryForList(Goods.class, sql, begin, pageSize);
        return goods;
    }


    @Override
    public Integer queryForPageTotalCountByprice(int min, int max) {
        String sql = "select COUNT(*) from t_book Where price >? AND price <? AND `stock`>1";

        Number count = (Number)queryForSingleValue(sql,min,max);

        return count.intValue();
    }
    @Override
    public List<Goods> queryForPageItemsByprice(int begin, int pageSize, int min, int max) {
        String sql = "select `id`,`name` , `author` , `price` , `sales` , `stock` , `img_path` imgPath From t_book " +
                "Where price >? AND price <? AND `stock`>1 ORDER BY price ASC LIMIT ?,?";
        List<Goods> goods = queryForList(Goods.class, sql,min,max, begin, pageSize);

        return goods;
    }


}
