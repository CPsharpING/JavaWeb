package com.atguigu.dao.impl;

import com.atguigu.dao.OrderDao;
import com.atguigu.pojo.Order;
import com.atguigu.pojo.OrderItem;
import com.atguigu.pojo.User;

import java.math.BigDecimal;
import java.util.List;

public class OrderDaoImpl extends BaseDao implements OrderDao {


    @Override
    public int saveOrder(Order order) {
        String sql = "insert into t_order(`order_id`,`create_time`,`price`,`status`,`user_id`)VALUES(?,?,?,?,?)";

        return update(sql, order.getOrderId(), order.getCreateTime(), order.getPrice(), order.getStatus(), order.getUserId());

    }

    @Override
    public List<OrderItem> queryItemByUser(User user) {
        String sql = "SELECT\n" +
                "\t`id`,\n" +
                "\t`name`,\n" +
                "\t`count`,\n" +
                "\tt_order_item.price,\n" +
                "\tt_order_item.total_price,\n" +
                "\tt_order.order_id\n" +
                "FROM\n" +
                "\tt_order_item\n" +
                "\tJOIN t_order \n" +
                "WHERE\n" +
                "\tt_order.order_id = t_order_item.order_id \n" +
                "\tAND t_order.user_id = ?";
        return queryForList(OrderItem.class,sql,user.getId());
    }

    @Override
    public List<Order> queryOrderByUser(User user) {

//<%--					private String orderId;--%>
//<%--					private Date createTime;--%>
//<%--					private BigDecimal price;--%>
//<%--					// 0未发货，1已发货，2表示已签收--%>
//<%--	                private Integer status = 0;--%>
//<%--					private Integer userId;--%>
        String sql = "SELECT\n" +
                "\torder_id orderId,\n" +
                "\tcreate_time createTime,\n" +
                "\tprice,\n" +
                "\t`status`,\n" +
                "\tuser_id userId \n" +
                "FROM\n" +
                "\tt_order \n" +
                "WHERE\n" +
                "\tuser_id = ?;";
        return queryForList(Order.class,sql,user.getId());
    }

    @Override
    public List<OrderItem> queryItemByOrder(String orderId) {
//        private Integer id;
//        private String name;
//        private Integer count;
//        private BigDecimal price;
//        private BigDecimal totalPrice;
        String sql = "SELECT\n" +
                "\t`id`,\n" +
                "\t`name`,\n" +
                "\t`count`,\n" +
                "\tprice,\n" +
                "\ttotal_price totalPrice ,\n" +
                "\torder_id\n" +
                "FROM\n" +
                "\tt_order_item\n" +
                "\tWHERE order_id = ?";
        return queryForList(OrderItem.class,sql,orderId);
    }

    @Override
    public List<Order> queryAllOrder() {
        String sql = "SELECT\n" +
                "\torder_id orderId,\n" +
                "\tcreate_time createTime,\n" +
                "\tprice,\n" +
                "\t`status`,\n" +
                "\tuser_id userId \n" +
                "FROM\n" +
                "\tt_order \n" ;
        return queryForList(Order.class,sql,null);
    }

    @Override
    public int setStatusById(String ID, int status) {
        String sql = "UPDATE t_order SET status = ? WHERE order_id = ?";


        return update(sql,status,ID);
    }


}
