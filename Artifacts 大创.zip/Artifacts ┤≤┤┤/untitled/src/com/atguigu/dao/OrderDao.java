package com.atguigu.dao;

import com.atguigu.pojo.Order;
import com.atguigu.pojo.OrderItem;
import com.atguigu.pojo.User;

import java.util.List;

public interface OrderDao {

    public int saveOrder(Order order);

    public List<OrderItem> queryItemByUser(User user);

    public List<Order> queryOrderByUser(User user);

    public List<OrderItem> queryItemByOrder(String orderId);

    public List<Order> queryAllOrder();

    public int setStatusById(String ID, int status);

}
