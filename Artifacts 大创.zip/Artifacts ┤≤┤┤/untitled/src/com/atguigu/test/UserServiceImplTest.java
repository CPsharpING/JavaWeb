package com.atguigu.test;

import com.atguigu.dao.impl.UserDaoImpl;
import com.atguigu.pojo.User;
import com.atguigu.service.UserService;
import com.atguigu.service.impl.UserServiceImpl;
import org.junit.Test;

import static org.junit.Assert.*;

public class UserServiceImplTest {

    @Test
    public void regisUser() {
        UserServiceImpl userService = new UserServiceImpl();
        userService.registUser(new User(null,"a","b","@"));
    }

    @Test
    public void login() {
        UserServiceImpl userService = new UserServiceImpl();
        User login = userService.login(new User(null, "a", "b", "@"));//用user登录
        System.out.println(login);
    }

    @Test
    public void existsUsername() {
        UserServiceImpl userService = new UserServiceImpl();
        boolean a = userService.existsUsername("b");
        System.out.println(a);
    }
}