package com.atguigu.test;

import com.atguigu.pojo.Cart;
import com.atguigu.pojo.CartItem;
import com.atguigu.pojo.Order;
import com.atguigu.service.OrderService;
import com.atguigu.service.impl.OrderServiceImpl;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.Assert.*;

public class OrderServiceTest {

    @Test
    public void createOrder() {
        OrderService orderService = new OrderServiceImpl();
        Cart cart = new Cart();
        cart.addItem(new CartItem(1,"1",1,new BigDecimal(1),new BigDecimal(1)));
        cart.addItem(new CartItem(1,"1",1,new BigDecimal(1),new BigDecimal(1)));
        cart.addItem(new CartItem(2,"2",1,new BigDecimal(1),new BigDecimal(1)));
        System.out.println(cart);
        orderService.createOrder(cart,1);


    }
    @Test
    public void queryAllOrder(){
        OrderService orderService = new OrderServiceImpl();
        List<Order> orders = orderService.queryAllOrder();
        orders.forEach(System.out::println);

    }
}