package com.atguigu.test;

import com.atguigu.dao.impl.BookDaoImpl;
import com.atguigu.pojo.Goods;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.List;

public class GoodsDaoTest {
    BookDaoImpl bookDao = new BookDaoImpl();
    @Test
    public void addBook() {
        Goods goods = new Goods(null, "1", "1", new BigDecimal(999), 1, 300, null);
        System.out.println(goods);
        bookDao.addBook(goods);

    }

    @Test
    public void deleteBookById() {
    }

    @Test
    public void updateBook() {
        Goods goods = new Goods(21, "2", "1", new BigDecimal(999), 1, 300, null);
        bookDao.updateBook(goods);
    }

    @Test
    public void queryById() {
        Goods goods = bookDao.queryById(21);
        System.out.println(goods);
    }

    @Test
    public void queryBooks() {
        bookDao.queryBooks().forEach(System.out::println);

    }

    @Test
    public void queryForPageTotalCount() {
        String sql = "select COUNT(*) from t_book";
        Integer integer = bookDao.queryForPageTotalCount();
        System.out.println(integer);


    }
    @Test
    public void queryForPageTotalCountByprice() {
        String sql = "select COUNT(*) from t_book";
        Integer integer = bookDao.queryForPageTotalCountByprice(0,10);
        System.out.println(integer);


    }

    @Test
    public void queryForPageItems() {
        String sql = "select `id`,`name` , `author` , `price` , `sales` , `stock` , `img_path` imgPath From t_book LIMIT ?,?";
        List<Goods> goods = bookDao.queryForPageItems(0, 4);
        goods.forEach(System.out::println);
    }
    @Test
    public void queryForPageItemsByprice() {
        String sql = "select `id`,`name` , `author` , `price` , `sales` , `stock` , `img_path` imgPath From t_book LIMIT ?,?";
        List<Goods> goods = bookDao.queryForPageItemsByprice(0, 4,0,10);
        goods.forEach(System.out::println);
    }

}