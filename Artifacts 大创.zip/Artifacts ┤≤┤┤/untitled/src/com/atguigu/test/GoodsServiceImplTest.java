package com.atguigu.test;

import com.atguigu.pojo.Goods;
import com.atguigu.pojo.Page;
import com.atguigu.service.BookService;
import com.atguigu.service.impl.BookServiceImpl;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.List;

public class GoodsServiceImplTest {
    private BookService bookService = new BookServiceImpl();
    @Test
    public void addBook() {
        Goods goods = new Goods(null, "2", "2", new BigDecimal(999), 2, 300, null);
        bookService.addBook(goods);
    }

    @Test
    public void deleteBookById() {

        bookService.deleteBookById(21);
    }

    @Test
    public void updateBook() {
        Goods goods = new Goods(22, "3", "2", new BigDecimal(999), 2, 300, null);
        bookService.updateBook(goods);
    }

    @Test
    public void queryById() {
        Goods goods = bookService.queryById(19);
        System.out.println(goods);
    }

    @Test
    public void queryBooks() {
        List<Goods> goods = bookService.queryBooks();
        goods.forEach(System.out::println);
    }
    @Test
    public void page() {
        Page<Goods> page = bookService.page(1, 4);
        List<Goods> items = page.getItems();
        items.forEach(System.out::println);
    }
    @Test
    public void pageByprice() {
        Page<Goods> page = bookService.pageByprice(1, Integer.MAX_VALUE,0,10);
        List<Goods> items = page.getItems();
        items.forEach(System.out::println);
    }
}