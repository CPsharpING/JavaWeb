package com.atguigu.test;

import com.atguigu.dao.OrderDao;
import com.atguigu.dao.impl.OrderDaoImpl;
import com.atguigu.pojo.Order;
import com.atguigu.pojo.OrderItem;
import com.atguigu.pojo.User;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.*;

public class OrderDaoTest {

    @Test
    public void saveOrder() {
        OrderDao orderDao = new OrderDaoImpl();
        orderDao.saveOrder(new Order("1",new Date(),new BigDecimal(100),1,1));

    }

    @Test
    public void queryItemByUser(){
        OrderDao orderDao = new OrderDaoImpl();
        List<OrderItem> orderItems = orderDao.queryItemByUser(new User(1, null, null, null));
        orderItems.forEach(System.out::println);
    }

    @Test
    public void setStatusById(){
        OrderDao orderDao = new OrderDaoImpl();
        orderDao.setStatusById("16737016279041",1);
        List<Order> orders = orderDao.queryAllOrder();
        orders.forEach(System.out::println);

    }

}