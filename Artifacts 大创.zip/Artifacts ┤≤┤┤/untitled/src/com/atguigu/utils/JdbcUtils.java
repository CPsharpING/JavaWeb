package com.atguigu.utils;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.pool.DruidDataSourceFactory;
import com.alibaba.druid.pool.DruidPooledConnection;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

public class JdbcUtils {
    private static DruidDataSource dataSource;
    private static ThreadLocal<Connection> conns = new ThreadLocal<>();

    static{
        InputStream resourceAsStream = JdbcUtils.class.getClassLoader().getResourceAsStream("jdbc.properties");
        Properties properties = new Properties();
        try{
            properties.load(resourceAsStream);
            dataSource = (DruidDataSource) DruidDataSourceFactory.createDataSource(properties);
            System.out.println("数据库连接池已创建成功");
        }catch (Exception e){
            System.out.println(e);
        }

    }
    public static Connection getConnection() {
        Connection connection = conns.get();
        if(connection==null){
            try{
                connection = dataSource.getConnection();
                conns.set(connection);
                connection.setAutoCommit(false);
            }catch (Exception e){
                e.printStackTrace();
            }


        }
        return connection;

    }
//    public static void close(Connection conn){
//        if(conn!=null){
//            try{
//                conn.close();
//            }catch (Exception e){
//                System.out.println(e);
//            }
//
//        }
//    }
    public static void commitAndClose(){
        Connection connection = conns.get();
        if(connection!=null){
            try{
                connection.commit();
            }catch (Exception e){
                e.printStackTrace();
            }finally {
                try{
                    connection.close();
                }catch (Exception e){
                    e.printStackTrace();
                }

            }

        }
        conns.remove();
    }
    public static void rollbackAndClose(){
        Connection connection = conns.get();
        if(connection!=null){
            try{
                connection.rollback();
            }catch (Exception e){
                e.printStackTrace();
            }finally {
                try{
                    connection.close();
                }catch (Exception e){
                    e.printStackTrace();
                }

            }

        }
        conns.remove();

    }




}
